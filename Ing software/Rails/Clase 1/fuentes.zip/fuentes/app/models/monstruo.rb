class Monstruo < ApplicationRecord
end
