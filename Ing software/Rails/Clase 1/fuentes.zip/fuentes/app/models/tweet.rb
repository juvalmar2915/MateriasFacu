class Tweet < ApplicationRecord

end
