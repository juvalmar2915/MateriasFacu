package prog3.ejercicio;

import prog3.arbol.general.ArbolGeneral;

public class AnalizadorArbol {

	public int cantHijosImpares(ArbolGeneral<Character> arbol) {
		// escriba su solucion a partir de aquí


		// fin del código de su solución
	}
	
	public static void main(String[] args) {
		// Casos de ejemplo para probar su implementación.
		// Se instancia el siguiente ejemplo:
		//
		//       A
		//     /   \
		//    B     C
		//  / | \    \
		// D  E  F    G
		//        \
		//         H
		
		ArbolGeneral<Character> arbolA = new ArbolGeneral<>('A');
		ArbolGeneral<Character> arbolB = new ArbolGeneral<>('B');
		ArbolGeneral<Character> arbolC = new ArbolGeneral<>('C');
		ArbolGeneral<Character> arbolD = new ArbolGeneral<>('D');
		ArbolGeneral<Character> arbolE = new ArbolGeneral<>('E');
		ArbolGeneral<Character> arbolF = new ArbolGeneral<>('F');
		ArbolGeneral<Character> arbolG = new ArbolGeneral<>('G');
		ArbolGeneral<Character> arbolH = new ArbolGeneral<>('H');
		
		arbolA.agregarHijo(arbolB);
		arbolA.agregarHijo(arbolC);
		
		arbolB.agregarHijo(arbolD);
		arbolB.agregarHijo(arbolE);
		arbolB.agregarHijo(arbolF);
		
		arbolC.agregarHijo(arbolG);
		
		arbolF.agregarHijo(arbolH);
		
		AnalizadorArbol analizador = new AnalizadorArbol();
		
		System.out.println("La cantidad de impares de A (deben ser 3): " + analizador.cantHijosImpares(arbolA));
		System.out.println("La cantidad de impares de B (deben ser 2): " + analizador.cantHijosImpares(arbolB));
		System.out.println("La cantidad de impares de F (deben ser 1): " + analizador.cantHijosImpares(arbolF));
		System.out.println("La cantidad de impares de E (deben ser 0): " + analizador.cantHijosImpares(arbolE));
	}

}
