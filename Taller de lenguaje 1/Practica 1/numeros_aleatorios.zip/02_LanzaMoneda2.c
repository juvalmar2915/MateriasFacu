/* Lanza una moneda 7000 veces */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{  int i, cara=0;

   srand(time(NULL));

   for (i=0; i<7000; i++)
      if (rand() % 2)  /* no es par */
      /* los n�meros impares se cuentan
         como cara */
         cara++;

    printf("Salieron %d caras y ", cara);
    printf("%d cecas\n", 7000-cara);
    return 0;
}
