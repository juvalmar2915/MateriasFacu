!#/bin/bash

bash