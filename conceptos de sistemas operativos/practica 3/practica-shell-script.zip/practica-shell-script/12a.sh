#!/bin/bash
echo "ingrese dos numeros"
read num1 num2 
echo "mult `expr $num1 \* $num2`"
echo "suma `expr $num1 + $num2`"
echo "resta `expr $num1 - $num2`"
if `expr $num1 > $num2`
then
echo "mayor $num1"
else
echo "mayor $num2"
fi
exit 0
