#!/bin/bash
echo "mult `expr $1 \* $2`"
echo "suma `expr $1 + $2`"
echo "resta `expr $1 - $2`"
if `expr $1 > $2`
then
echo "mayor $1"
else
echo "mayor $2"
fi
exit 0
