#!/bin/bash
for ((i=1;i<101;i++))
do
echo "el valor de $i al cuadrado es `expr $i \* $i`"
done
exit 0
