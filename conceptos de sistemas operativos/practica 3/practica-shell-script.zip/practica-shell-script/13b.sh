#!/bin/bash
echo "Elija una opcion: Listar (presione 1) DondeEstoy (presione 2) QuienEsta(presione 3)"
read num
case $num in
"1")
echo "`ls -a`"
;;
"2")
echo "`pwd`"
;;
"3")
echo "`who`"
;;
esac
exit 0
