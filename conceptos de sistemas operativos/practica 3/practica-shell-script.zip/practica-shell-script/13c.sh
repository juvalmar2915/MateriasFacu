#!/bin/bash
if [ -d $1 ]
then
echo "el archivo es un directorio"
elif [ -f $1 ]
then
echo "archivo es archivo"
else
mkdir $1
fi
exit 0
