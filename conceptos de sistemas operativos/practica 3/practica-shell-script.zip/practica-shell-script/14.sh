#!/bin/bash
if [ $# -ne 3 ]
then
echo "la cantidad de parametros es incorrecta"
exit 1
fi
if [ ! -d $1 ]
then
echo "el primer parametro no es un directorio"
exit 2
fi
case $2 in
"-a")
for i in `ls $1`; do
mv $1/$i $1/$i$3
done
;;
"-b")
for i in `ls $1`; do
mv $1/$i $1/$3$i
done
;;
*)
echo "el segundo parametro debe ser -a o -b"
exit 4
esac
