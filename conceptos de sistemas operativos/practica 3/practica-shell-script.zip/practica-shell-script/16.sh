#!/bin/bash
if [ $# -ne 1 ]
then
echo "no se ingreso la cantidad de parametros correcta"
exit 1
fi
echo "$USER `find ~ -name *$1 | wc -l`" >> ~/reporte.txt
#echo "$USER `locate *$1 | wc -l`" >> ~/reporte.txt
exit 0
