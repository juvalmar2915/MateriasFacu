#!/bin/bash
for i in $(ls $pwd)
do
echo $i | tr '[:lower:][:upper:]' '[:upper:][:lower:]'
done
exit 0
