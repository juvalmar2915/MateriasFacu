#!/bin/bash
if [ $# -ne 1 ]
then
echo "la cant de parametros no es correcta"
exit 1
fi
while true; do
selogueo=`who | grep $1 | wc -l`
if [ $selogueo != 0 ]
then
echo "usuario se ha logeado"
exit 0
fi
sleep 10
done
