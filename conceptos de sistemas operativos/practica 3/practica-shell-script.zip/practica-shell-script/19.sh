#!/bin/bash
echo "Menu de comandos"
num=0
for i in $(ls ~/practica-shell-script)
do
echo "$num. $i" 
let "num=num+1"
done
echo "ingrese la opcion a ejecutar:"
read num1
opcion=0
for x in $(ls ~/practica-shell-script)
do
if [ $opcion == $num1 ]
then
~/practica-shell-script/$x
exit 0
fi
let "opcion=opcion+1"
done
exit 1
