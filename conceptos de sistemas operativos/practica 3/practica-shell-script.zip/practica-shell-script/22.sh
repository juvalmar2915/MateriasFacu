#!/bin/bash
num=(10 3 5 7 9 3 5 4)
function productoria
{
local num1=1
for ((i=0; i < ${#num[*]}; i++))
do
let num1*=${num[$i]}
done
echo $num1
return 0
}

productoria
