#!/bin/bash
num=(10 3 5 7 9 3 5 4)
cantimpar=0
for ((i=0; i < ${#num[*]} ; i++))
do
if [ `expr ${num[i]} % 2` = 0 ]
then
echo ${num[i]}
else
let "cantimpar++"
fi
done
echo $cantimpar
