vector1=( 1 80 65 35 2)
vector2=( 5 98 3 41 8)
if [ ${#vector1[*]} = ${#vector2[*]} ]
then
for ((i=0; i < ${#vector1[*]} ; i++))
do
echo "La suma de los elementos de la posicion $i de los vectores es `expr ${vector1[$i]} + ${vector2[$i]}`"
done
else
echo "los vectores no tienen la misma dimension"
fi
