#!/bin/bash
configruta="/etc/passwd"
arreglousers=()
for i in $(cat $configruta | cut -f 1 -d ':')
do
	arreglousers[${#arreglousers[*]}]=$i
done
case $1 in
  "-b")
	if [ $# -lt 2 ]
	then
	echo "no se paso un elemento n a imprimir en el arreglo"
	exit 1
	else
		if [ ${#arreglousers[*]} -gt $2 ]
		then
		echo "El usuario en la pos $2 es ${arreglousers[$2]}"
		else
		echo "no existe el elemento $2 en el arreglo"
		fi 
	fi
   ;;
   "-l")
	echo "la longitud del arreglo es ${#arreglousers[*]}"
   ;;
   "-i")
	for ((i=0; i < ${#arreglousers[*]} ; i++))
	do
	echo "elemento en pos $i = ${arreglousers[$i]}"
	done
   ;;
   esac
exit 0
