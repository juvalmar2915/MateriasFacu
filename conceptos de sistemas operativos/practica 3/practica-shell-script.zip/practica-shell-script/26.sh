#!/bin/bash
if [ $# -ge 1 ]
then
parametros=1
archinexistentes=0
for i in $*
do
if [ `expr $parametros % 2` != 0 ]
then
if [ -f $i ] 
then
echo "$i es un archivo"
elif [ -d $i ]
then
echo "$i es un directorio"
else
let "archinexistentes+=1"
fi
fi
let "parametros+=1"
done
echo "cant archivos inexistentes= $archinexistentes"
else
echo "no se paso ningun parametro"
fi
