#!/bin/bash
arreglo=();

inicializar(){
arreglo=();
echo "arreglo iniciado";
}

agregar_elem(){
if [ $# -ne 1];
then
echo "Ingrese un parametro";
return 1;
fi
arreglo=(${arreglo[*] $1)
echo "elemento $1 agregado"
}

eliminar_elem(){
if [ $# -ne 1];
then
echo "Ingrese un parametro";
return 1;
fi
if [ $1 -ge ${#arreglo[*]} ];
then
echo "Posicion invalida"
return 2
fi
unset arreglo[$1];
arreglo=(${arreglo[*]});
echo "elemento $1 fue eliminado"
}

longitud(){
echo ${#arreglo[*]};
}

imprimir(){
echo ${arreglo[*]};
}

inicializar_Con_Valores(){
if [ $# -ne 2 ]; 
then
echo "cant de parametros ingresada es incorrecta"
return 1
fi
iniciar
for ((i=0; i < $1; i++))
do
  agregar_elem $2
done
echo "arreglo inicializado con $1 veces el valor $2"
}
