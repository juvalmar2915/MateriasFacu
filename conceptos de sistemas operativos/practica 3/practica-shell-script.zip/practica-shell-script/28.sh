#!/bin/bash
if [ $# -ne 1 ]
then
echo "no se paso el directorio requerido"
exit 1
fi
if [ -d $1 ]
then

else
echo "el parametro pasado no es un directorio"
exit 4
fi
