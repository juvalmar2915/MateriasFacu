#!/bin/bash
borrarArchivo(){
if [ $# -ne 1 ];
then
echo "Ingrese un parametro";
return 1;
fi
echo "desea eliminar el archivo logicamente?s/n"
read -n1 logicamente
for ((i=0; i < ${#arreglo[*]}; i++))
do
if [ $1 = ${arreglo[$i]} ]
then
unset arreglo[$i]
arreglo=(${arreglo[*]});
echo "elemento $1 fue eliminado"
if [ $logicamente = "n" ]
then
rm -f $1
fi
return 0
fi
done
echo "archivo no encontrado"
return 10
}

cantidadArchivos(){
echo ${#arreglo[*]};
}

verArchivo(){
if [ $# -ne 1];
then
echo "Ingrese un parametro";
return 1;
fi
for ((i=0; i < ${#arreglo[*]}; i++))
do
if [ $1 = ${arreglo[$i]} ]
then
echo "vizualizando $1"
cat $1
return 0
fi
done
echo "archivo no encontrado"
return 5
}

#el ejercicio dice de agregar solo elementos del home y sin procesar los del
#subdirectorios por lo que uso ls en vez de find
#inicio codigo
arreglo=()
cd ~
for i in `ls *.doc`
do
arreglo=(${arreglo[*]} $i)
done
verArchivo u.doc 
cantidadArchivos
borrarArchivo xd.doc
cantidadArchivos
