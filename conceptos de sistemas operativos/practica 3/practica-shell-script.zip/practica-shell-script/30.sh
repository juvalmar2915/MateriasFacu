#!/bin/bash
directorio=~/bin
cantmovidos=0
if [ ! -d $directorio ]
then
echo "no existia la carpeta por lo cual fue creada"
mkdir ~/bin 
fi
for i in `find . -maxdepth 1 -type f | cut -d / -f 2`
do
if [ -x $i ]
then
mv $i ~/bin
let "cantmovidos+=1"
echo "se movio el archivo $i"
fi
done
echo "se movieron $cantmovidos archivos"
